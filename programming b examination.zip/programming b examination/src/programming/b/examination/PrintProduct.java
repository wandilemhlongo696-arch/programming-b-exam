package programming.b.examination;

import java.text.DecimalFormat;
import java.util.Scanner;
import static javax.management.Query.value;
public class Main {
    private static final int MONTHS = 3;
    public static void main(String[] args){
        Scanner input = new 
            Scanner(system.in);
        // Single dimentional array of product names 
        String[] ProductNames = {"Cozy Nights Monarch","restonic barbados","sealy phuket"};
        // Two dimensional array: rows = product, columns = months
        int[][] sales = new 
            int [ProductNames.length][MONTHS];
        
        for (int p = 0; p <
                ProductNames.length; p++) {
            for (int m = 0; m < MONTHS; m++){
                sales [p][m] = 
                        ReadSales(input, m + 1, ProductNames[p]);
            }
            System.out.println();
        }
        Product product = new 
            PrintProduct(ProductNames, sales);
        new
            PrintProduct(product).PrintReport(); input.close();
    }
    // Promts util a valid non negative whole number is entered
    private static int ReadSales(Scanner input, int month, String name){
        while(true){
            System.out.println("Enter number of sales for month" + month + "for" + name "mattress:");
            if (input.hasNextInt()){
                input.hasNextInt();
                if (value>= 0){
                    return value;
                }
                else{
                    input.hasNext(); // discard invalid text
                }
                System.out.println("invalid input. Please enter a whole number of 0 or more.");
            }
        }
    }
}

public class product implements Iproduct {
    
    private final String [] ProductNames;
    private final int[][] sales;
    
    public products (String [] ProductNames, int [][] sales ){
        this.ProductNames = ProductNames;
        int[][] Sales = null;
        this.sales = Sales;
    }
    // adds up every sale for every product in every month
    public int GetTotalProductsSold(){
        int Total = 0; 
        for (int p = 0; p < sales.length; p++){
            total += GetProductTotal(p);
        }
        return Total;
    }
    // Total sale / (number of products x number of months)
    public double GetAvarageProductSold(){
        if (sales.length == 0 
                sales[0].length == 0){
        return 0; 
    }
                int entries = sales.length *
                        sales[0].length;
                rerurn (double)
                        GetTotalProductsSold() / entries;
    }
    // finds the product with the highest total sales overall months 
    public String GetMostPopulerProduct(){
        int best = 0;
        for (int p = 1 ; p < sales .length; p++){
            if (GetProductTotal(p) > GetProductTotal(best)){
                best = p;
            }
        }
        return ProductNames [best] + "(" + 
                GetProductTotal (best) + ")";
        // helper total sales for one product across all months 
        private int GetProductTotal(int productIndex){
            int total = 0;
                for (int sale :
                        sales[productIndex]){
                    
                total += sales;
                
                
        }
                return total;
    }
}


public class PrintProduct {

    private final IProduct product;

    public PrintProduct(IProduct product) {
        this.product = product;
    }

    public void PrintTotalSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void PrintAverageSales() {
        // "#.##" prints 17.0 as 17 but keeps decimals when needed
        DecimalFormat format = new DecimalFormat("#.##");
        System.out.println("AVERAGE PRODUCT SALES: " + format.format(product.GetAverageProductSold()));
    }

    public void PrintMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }

    public void PrintReport() {
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("*".repeat(40));
        PrintTotalSales();
        PrintAverageSales();
        PrintMostPopularProduct();
    }
}